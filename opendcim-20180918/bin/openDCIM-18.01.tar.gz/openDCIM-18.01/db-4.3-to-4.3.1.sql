--
-- Bump up the database version (uncomment below once released)
--

UPDATE fac_Config set Value="4.3.1" WHERE Parameter="Version";
