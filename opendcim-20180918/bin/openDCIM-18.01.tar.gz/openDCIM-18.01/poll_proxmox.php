<?php

	require_once "db.inc.php";
	require_once "facilities.inc.php";

	// Change to true if you want lots of help figuring out your problems
	$debug = false;

	PMox::UpdateInventory( $debug );

?>
