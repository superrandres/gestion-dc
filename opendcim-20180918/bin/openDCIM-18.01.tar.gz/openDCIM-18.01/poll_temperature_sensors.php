<?php
	require("db.inc.php");
	require("facilities.inc.php");
	
	Device::UpdateSensors();
?>
